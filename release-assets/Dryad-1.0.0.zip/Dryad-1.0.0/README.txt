Dryad 1.0.0 - Windows x64

1. Restart Clash of Clans before replacing an injected overlay.
2. Run Dryad.exe, approve this computer in your browser using your verified
   account and active membership, and leave the launcher running.
3. Run DryadInjector.exe beside Dryad.dll and choose Inject / Resume.
4. Insert opens the overlay. Scripts > Farming Script starts. F8 stops.

License ownership and hardware are checked. A copied license from another
computer, development license, expired lease, or invalid signature is rejected.
Leases renew after five minutes and expire within ten minutes. Keep the launcher
running. If the computer identity changes, reset the old device in your account
and pair again. No separate .NET installation is required.

Settings save to PlayOverlay.ini. Continuous capture is off by default.
Only the latest 10 debugging diagnostic bundles and 10 runtime logs are kept.
Wall dumping preserves 100,000 gold for matchmaking.

Hosted licensing activated November 3, 2026: the production signer and protected
1.0.0 download catalog are live. Stripe billing is still unconfigured. Sign-in
requires a legitimately entitled account; activation does not grant membership.
Windows Authenticode executable signing is not configured.
