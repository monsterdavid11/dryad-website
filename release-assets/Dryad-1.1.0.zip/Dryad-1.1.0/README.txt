Dryad 1.1.0

Extract all files into a folder you can write to.
Run Dryad.exe, approve this computer in your browser and keep Dryad open.
Choose Open overlay controls, then Inject / Resume.
Insert opens the overlay menu; F8 stops farming.

Updates check automatically after sign-in and every 15 minutes.
Newer signed packages replace Dryad.exe, DryadInjector.exe and Dryad.dll.
Close the game and overlay controls when an update is ready. Dryad then
installs automatically and restarts. Your config and account state are preserved.
Never overwrite a loaded overlay DLL; Stop does not unload it.

Developer mode has no launcher checkbox or generated default config entry.
To explicitly enable it, close the game and add developerMode=1 under
[Settings] in PlayOverlay.ini. Restart the game and inject to apply it.
Use developerMode=0 or remove the entry to hide diagnostics again.

Active membership is required. Production signing and hardware binding remain.
This local build does not publish itself to the website; the backend package
update change and a matching release catalog package must be deployed first.
